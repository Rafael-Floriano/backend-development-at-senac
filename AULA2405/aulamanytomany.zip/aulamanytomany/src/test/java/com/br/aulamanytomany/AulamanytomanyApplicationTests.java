package com.br.aulamanytomany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulamanytomanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
