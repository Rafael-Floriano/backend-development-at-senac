package com.br.aulamanytomany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulamanytomanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AulamanytomanyApplication.class, args);
	}

}
